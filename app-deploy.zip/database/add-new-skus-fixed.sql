-- Add new SKUs to Cleaned_FG_Master_file table with default descriptions

INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC10020SA', 'FXC10020SA', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC170020S', 'FXC170020S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC17005S', 'FXC17005S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC20050S', 'FXC20050S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC30050S', 'FXC30050S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC60005S', 'FXC60005S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC73010S', 'FXC73010S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC73030SA', 'FXC73030SA', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC74050S', 'FXC74050S', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC75010SA', 'FXC75010SA', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC75020SA', 'FXC75020SA', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXCM', 'FXCM', 'PCS', NOW(), 365) ON CONFLICT (sku) DO NOTHING;

-- Sync to active_skus table
INSERT INTO active_skus (sku, is_active)
SELECT sku, true FROM "Cleaned_FG_Master_file"
WHERE sku IN ('FXC10020SA', 'FXC170020S', 'FXC17005S', 'FXC20050S', 'FXC30050S', 'FXC60005S', 'FXC73010S', 'FXC73030SA', 'FXC74050S', 'FXC75010SA', 'FXC75020SA', 'FXCM')
ON CONFLICT (sku) DO UPDATE SET is_active = true;
