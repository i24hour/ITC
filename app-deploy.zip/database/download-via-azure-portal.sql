-- ============================================
-- CLEANED_FG_MASTER_FILE CSV EXPORT
-- Run this in Azure Cloud Shell (PowerShell mode)
-- ============================================

-- ============================================
-- FOR AZURE CLOUD SHELL - COPY THIS EXACT COMMAND:
-- ============================================

az postgres flexible-server execute --name itc-warehouse-db-2025 --admin-user priyanshu8593@itc-warehouse-db-2025 --admin-password "YOUR_PASSWORD_HERE" --database-name itc_warehouse --querytext "SELECT sku, description, uom, aging_days, created_at FROM \"Cleaned_FG_Master_file\" ORDER BY sku;" --output table

-- Replace YOUR_PASSWORD_HERE with your actual password
-- This runs in bash (Azure Cloud Shell)
-- Results will display in the terminal

-- ============================================
-- EASIER OPTION: Use Azure Portal Query Editor
-- ============================================
-- 1. Close Cloud Shell
-- 2. Go to your database in Azure Portal
-- 3. Click "Query editor" (preview) in left menu
-- 4. Paste this SQL:

SELECT 
  sku,
  description,
  uom,
  aging_days,
  created_at
FROM "Cleaned_FG_Master_file"
ORDER BY sku;

-- 5. Click Run
-- 6. Click "Download" button to get CSV


-- OPTION 2: View Data in Query Editor
-- Run this to see all records in Azure Portal
-- You can then export from the results grid
-- --------------------------------------------
-- SELECT 
--   sku AS "SKU",
--   description AS "Description",
--   uom AS "UOM",
--   aging_days AS "Aging Days",
--   created_at AS "Created At"
-- FROM "Cleaned_FG_Master_file"
-- ORDER BY sku;


-- OPTION 3: Check Table Stats First
-- Run this to see how many records exist
-- --------------------------------------------
-- SELECT 
--   COUNT(*) as total_records,
--   COUNT(aging_days) as records_with_aging,
--   COUNT(*) - COUNT(aging_days) as records_without_aging
-- FROM "Cleaned_FG_Master_file";


-- ============================================
-- INSTRUCTIONS:
-- ============================================
-- 1. Login to Azure Portal: https://portal.azure.com
-- 2. Navigate to: itc-warehouse-db-2025.postgres.database.azure.com
-- 3. Click "Query editor" in left sidebar
-- 4. Login with database credentials
-- 5. Paste OPTION 1 query above
-- 6. Click "Run"
-- 7. Copy all results
-- 8. Save in a text file as: Cleaned_FG_Master_file_export.csv
-- ============================================
