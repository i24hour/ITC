-- ============================================
-- ADD AGING COLUMN TO DATABASE
-- Run this in Azure Portal Query Editor
-- ============================================

-- Step 1: Check if aging_days column exists
SELECT column_name 
FROM information_schema.columns 
WHERE table_name = 'Cleaned_FG_Master_file' 
  AND column_name = 'aging_days';

-- Step 2: Add aging_days column if not exists
ALTER TABLE "Cleaned_FG_Master_file" 
ADD COLUMN IF NOT EXISTS aging_days INTEGER DEFAULT NULL;

-- Step 3: Verify column was added
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'Cleaned_FG_Master_file';

-- ============================================
-- NOW POPULATE AGING DATA FROM EXCEL
-- ============================================

-- You need to provide the Excel data as SQL INSERT/UPDATE statements
-- Format should be:
-- UPDATE "Cleaned_FG_Master_file" SET aging_days = 45 WHERE sku = 'SKU001';
-- UPDATE "Cleaned_FG_Master_file" SET aging_days = 30 WHERE sku = 'SKU002';
-- etc.

-- ============================================
-- VERIFY AGING DATA
-- ============================================
SELECT 
  COUNT(*) as total_records,
  COUNT(aging_days) as with_aging,
  COUNT(*) - COUNT(aging_days) as without_aging,
  AVG(aging_days) as avg_aging,
  MIN(aging_days) as min_aging,
  MAX(aging_days) as max_aging
FROM "Cleaned_FG_Master_file";
