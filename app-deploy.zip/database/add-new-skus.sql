-- Add new SKUs to Cleaned_FG_Master_file table

INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC10020SA', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC170020S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC17005S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC20050S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC30050S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC60005S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC73010S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC73030SA', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC74050S', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC75010SA', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXC75020SA', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
INSERT INTO "Cleaned_FG_Master_file" (sku, description, uom, created_at, expire_in_days) VALUES ('FXCM', NULL, NULL, NOW(), NULL) ON CONFLICT (sku) DO NOTHING;
