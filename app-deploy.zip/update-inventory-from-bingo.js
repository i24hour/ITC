const { Client } = require('pg');
const fs = require('fs');
const csv = require('csv-parser');

const client = new Client({
  host: 'itc-warehouse-db-2025.postgres.database.azure.com',
  port: 5432,
  database: 'itc_warehouse',
  user: 'itcadmin',
  password: 'priyanshu@123',
  ssl: { rejectUnauthorized: false }
});

async function updateInventoryFromBingo() {
  try {
    await client.connect();
    console.log('✅ Connected to database\n');

    // Step 1: Clear old Inventory table data
    console.log('🗑️  Clearing old Inventory table data...');
    await client.query('DELETE FROM "Inventory"');
    console.log('✅ Old data cleared\n');

    // Step 2: Read BINGO STOCK CSV (skip first 2 header rows)
    console.log('📖 Reading BINGO STOCK  26.11.2025.xlsx - STOCK SHEET.csv...');
    const bingoData = [];
    let lineCount = 0;
    
    await new Promise((resolve, reject) => {
      fs.createReadStream('BINGO STOCK  26.11.2025.xlsx - STOCK SHEET.csv')
        .pipe(csv())
        .on('data', (row) => {
          lineCount++;
          // Skip first 2 rows (extra headers)
          if (lineCount <= 2) return;
          
          // Parse the row - column names from line 3
          const binNo = row['BIN NO'] || row['Bin No'] || row['bin_no'];
          const sku = row['SKU'] || row['sku'];
          const batchNo = row['BATCH'] || row['Batch'] || row['batch_no'] || row['BATCH NO'];
          const cfc = row['CFC'] || row['cfc'];
          
          // Only add if we have required fields and not empty
          if (binNo && sku && batchNo && cfc && binNo.trim() !== '') {
            bingoData.push({
              bin_no: binNo.trim(),
              sku: sku.trim(),
              batch_no: batchNo.trim(),
              cfc: parseInt(cfc) || 0
            });
          }
        })
        .on('end', resolve)
        .on('error', reject);
    });

    console.log(`✅ Found ${bingoData.length} valid records from BINGO STOCK\n`);

    if (bingoData.length === 0) {
      console.log('⚠️  No valid data found in BINGO STOCK file!');
      console.log('✅ Inventory table is now empty as requested.');
      return;
    }

    // Step 3: Get SKU details from Cleaned_FG_Master_file
    console.log('📋 Fetching SKU details from master file...');
    const skuDetails = {};
    for (const item of bingoData) {
      if (!skuDetails[item.sku]) {
        const result = await client.query(
          'SELECT description, uom FROM "Cleaned_FG_Master_file" WHERE sku = $1',
          [item.sku]
        );
        if (result.rows.length > 0) {
          skuDetails[item.sku] = {
            description: result.rows[0].description,
            uom: result.rows[0].uom
          };
        } else {
          skuDetails[item.sku] = {
            description: item.sku,
            uom: 2.0
          };
        }
      }
    }

    // Step 4: Insert into Inventory table
    console.log('📝 Inserting data into Inventory table...');
    let insertedCount = 0;
    
    for (const item of bingoData) {
      const details = skuDetails[item.sku];
      
      await client.query(`
        INSERT INTO "Inventory" (bin_no, sku, batch_no, cfc, description, uom, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
      `, [
        item.bin_no,
        item.sku,
        item.batch_no,
        item.cfc,
        details.description,
        details.uom
      ]);
      
      insertedCount++;
      if (insertedCount % 100 === 0) {
        console.log(`   Inserted ${insertedCount} records...`);
      }
    }

    console.log(`\n✅ Successfully inserted ${insertedCount} records into Inventory table!`);

    // Step 5: Download updated Inventory table
    console.log('\n📥 Downloading updated Inventory table...');
    const result = await client.query('SELECT * FROM "Inventory" ORDER BY id');

    const headers = ['ID', 'Bin No', 'SKU', 'Batch No', 'CFC', 'Description', 'UOM', 'Created At', 'Updated At', 'Expire Days'];
    let csvContent = headers.join(',') + '\n';

    result.rows.forEach(row => {
      csvContent += [
        row.id || '',
        row.bin_no || '',
        row.sku || '',
        row.batch_no || '',
        row.cfc || '',
        '"' + (row.description || '').replace(/"/g, '""') + '"',
        row.uom || '',
        row.created_at || '',
        row.updated_at || '',
        row.expire_days || ''
      ].join(',') + '\n';
    });

    fs.writeFileSync('database/Inventory_2025-11-27.csv', csvContent);
    console.log('✅ Updated CSV saved to: database/Inventory_2025-11-27.csv');
    console.log(`📊 Total records in Inventory table: ${result.rows.length}`);

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error);
  } finally {
    await client.end();
  }
}

updateInventoryFromBingo();
