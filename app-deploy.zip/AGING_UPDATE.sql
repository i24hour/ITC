-- ============================================
-- AGING COLUMN UPDATE SQL
-- Run this in Azure Portal Query Editor
-- ============================================

-- Step 1: Add column
ALTER TABLE "Cleaned_FG_Master_file" 
ADD COLUMN IF NOT EXISTS aging_days INTEGER DEFAULT NULL;

-- Step 2: Update aging values
BEGIN;

UPDATE "Cleaned_FG_Master_file" SET aging_days = 42 WHERE sku = 'FXC10005PB';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 6 WHERE sku = 'FXC10005SLA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 15 WHERE sku = 'FXC10010SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 6 WHERE sku = 'FXC10020SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 56 WHERE sku = 'FXC170005PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 12 WHERE sku = 'FXC170005S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 12 WHERE sku = 'FXC170010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 12 WHERE sku = 'FXC170020S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 6 WHERE sku = 'FXC20005SC';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 11 WHERE sku = 'FXC20010SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 57 WHERE sku = 'FXC20015';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 23 WHERE sku = 'FXC20015S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 15 WHERE sku = 'FXC20020SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 5 WHERE sku = 'FXC20050S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 47 WHERE sku = 'FXC30005PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 11 WHERE sku = 'FXC30005SLA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 21 WHERE sku = 'FXC30010SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 57 WHERE sku = 'FXC30011PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 15 WHERE sku = 'FXC30020SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 21 WHERE sku = 'FXC40005SL';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 22 WHERE sku = 'FXC40020S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 67 WHERE sku = 'FXC60005P';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 9 WHERE sku = 'FXC60005S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 5 WHERE sku = 'FXC70010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 3 WHERE sku = 'FXC70020SB';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 5 WHERE sku = 'FXC70051S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 51 WHERE sku = 'FXC71010PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 8 WHERE sku = 'FXC71010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 15 WHERE sku = 'FXC71020SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 37 WHERE sku = 'FXC72010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 51 WHERE sku = 'FXC72020PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 38 WHERE sku = 'FXC72020SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 52 WHERE sku = 'FXC72030PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 38 WHERE sku = 'FXC72030SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 54 WHERE sku = 'FXC73010PA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 7 WHERE sku = 'FXC73010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 54 WHERE sku = 'FXC73030IN';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 7 WHERE sku = 'FXC73030SA';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 20 WHERE sku = 'FXC74010S';
UPDATE "Cleaned_FG_Master_file" SET aging_days = 21 WHERE sku = 'FXC74020SA';

COMMIT;

-- Step 3: Verify
SELECT 
  COUNT(*) as total_skus,
  COUNT(aging_days) as skus_with_aging,
  AVG(aging_days) as avg_aging,
  MIN(aging_days) as min_aging,
  MAX(aging_days) as max_aging
FROM "Cleaned_FG_Master_file";

-- Show sample
SELECT sku, description, aging_days
FROM "Cleaned_FG_Master_file"
WHERE aging_days IS NOT NULL
ORDER BY aging_days DESC
LIMIT 10;
