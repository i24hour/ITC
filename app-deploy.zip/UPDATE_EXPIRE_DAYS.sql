-- ============================================
-- REPLACE aging_days WITH expire_in_days
-- Run this in Azure Portal Query Editor
-- ============================================

-- Step 1: Drop old column
ALTER TABLE "Cleaned_FG_Master_file" DROP COLUMN IF EXISTS aging_days;

-- Step 2: Add new columns
ALTER TABLE "Cleaned_FG_Master_file" 
ADD COLUMN IF NOT EXISTS mfd_date DATE DEFAULT NULL,
ADD COLUMN IF NOT EXISTS expiry_date DATE DEFAULT NULL,
ADD COLUMN IF NOT EXISTS expire_in_days INTEGER DEFAULT NULL;

-- Step 3: Update values
BEGIN;

UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-09-17', expiry_date = '2026-01-15', expire_in_days = 120 WHERE sku = 'FXC10005PB';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-24', expiry_date = '2026-04-22', expire_in_days = 180 WHERE sku = 'FXC10005SLA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-23', expiry_date = '2026-04-21', expire_in_days = 180 WHERE sku = 'FXC10010SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-23', expiry_date = '2026-04-21', expire_in_days = 180 WHERE sku = 'FXC10020SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-17', expiry_date = '2026-04-15', expire_in_days = 180 WHERE sku = 'FXC170005S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-17', expiry_date = '2026-04-15', expire_in_days = 180 WHERE sku = 'FXC170010S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-17', expiry_date = '2026-04-15', expire_in_days = 180 WHERE sku = 'FXC170020S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-24', expiry_date = '2026-04-22', expire_in_days = 180 WHERE sku = 'FXC20005SC';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-24', expiry_date = '2026-04-22', expire_in_days = 180 WHERE sku = 'FXC20010SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-23', expiry_date = '2026-04-21', expire_in_days = 180 WHERE sku = 'FXC20020SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-24', expiry_date = '2026-06-21', expire_in_days = 240 WHERE sku = 'FXC20050S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-20', expiry_date = '2026-04-18', expire_in_days = 180 WHERE sku = 'FXC30005SLA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-20', expiry_date = '2026-04-18', expire_in_days = 180 WHERE sku = 'FXC30020SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-08-23', expiry_date = '2025-12-21', expire_in_days = 120 WHERE sku = 'FXC60005P';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-20', expiry_date = '2026-04-18', expire_in_days = 180 WHERE sku = 'FXC60005S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-26', expiry_date = '2026-04-24', expire_in_days = 180 WHERE sku = 'FXC70010S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-26', expiry_date = '2026-04-24', expire_in_days = 180 WHERE sku = 'FXC70020SB';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-26', expiry_date = '2026-06-23', expire_in_days = 240 WHERE sku = 'FXC70051S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-21', expiry_date = '2026-04-19', expire_in_days = 180 WHERE sku = 'FXC71010S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-21', expiry_date = '2026-04-19', expire_in_days = 180 WHERE sku = 'FXC71020SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-09-22', expiry_date = '2026-03-21', expire_in_days = 180 WHERE sku = 'FXC72010S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-09-22', expiry_date = '2026-03-21', expire_in_days = 180 WHERE sku = 'FXC72020SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-09-21', expiry_date = '2026-03-20', expire_in_days = 180 WHERE sku = 'FXC72030SA';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-23', expiry_date = '2026-04-21', expire_in_days = 180 WHERE sku = 'FXC73010S';
UPDATE "Cleaned_FG_Master_file" SET mfd_date = '2025-10-22', expiry_date = '2026-04-20', expire_in_days = 180 WHERE sku = 'FXC73030SA';

COMMIT;

-- Step 4: Verify
SELECT 
  COUNT(*) as total_skus,
  COUNT(expire_in_days) as skus_with_expiry_days,
  AVG(expire_in_days) as avg_expire_days,
  MIN(expire_in_days) as min_expire_days,
  MAX(expire_in_days) as max_expire_days
FROM "Cleaned_FG_Master_file";

-- Show sample with dates
SELECT sku, description, mfd_date, expiry_date, expire_in_days
FROM "Cleaned_FG_Master_file"
WHERE expire_in_days IS NOT NULL
ORDER BY expire_in_days DESC
LIMIT 10;
